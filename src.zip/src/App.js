import React from 'react'

import Investments from './components/Investments'
import BattleGround from './components/BattleGround'
import Financeapp from './components/Financeapp'
import Insurance from './components/Insurance'
import Genierecommends from './components/Genierecommends'
import Footersection from './components/Footersection'

export default function App() {
  return (
    <>
    <Investments />
    <BattleGround/>
    <Genierecommends />
    <Insurance />
    <Financeapp/>
    <Footersection/> 
    </>
  )
}
